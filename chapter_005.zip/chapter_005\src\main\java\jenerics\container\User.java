package jenerics.container;

/**
 * Class model of objects User
 * @author Aleksei Usov
 * @since 17/12/2020
 */

public class User extends Base {

    public User(String id, String name) {
        super(id);
    }
}
