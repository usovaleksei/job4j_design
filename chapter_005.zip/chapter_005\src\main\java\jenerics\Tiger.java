package jenerics;

public class Tiger extends Predator {
}
