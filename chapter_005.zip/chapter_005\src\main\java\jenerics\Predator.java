package jenerics;

public class Predator extends Animal {
}
