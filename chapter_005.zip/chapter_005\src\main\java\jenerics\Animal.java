package jenerics;

public class Animal {
}
