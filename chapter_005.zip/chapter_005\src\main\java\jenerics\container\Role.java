package jenerics.container;

/**
 * Class model of objects Role
 * @author Aleksei Usov
 * @since 17/12/2020
 */

public class Role extends Base {

    public Role(String id, String roleName) {
        super(id);
    }
}
